import React from 'react'

export default function Page1() {
  return (
    <div>Page1</div>
  )
}
