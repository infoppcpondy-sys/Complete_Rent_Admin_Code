import React from 'react'

export default function Page2() {
  return (
    <div>Page2</div>
  )
}
