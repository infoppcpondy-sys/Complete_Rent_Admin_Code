import React from 'react'

export default function Page3() {
  return (
    <div>Page3</div>
  )
}
