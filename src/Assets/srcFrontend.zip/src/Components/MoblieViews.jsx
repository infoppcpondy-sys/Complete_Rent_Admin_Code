



import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Main from './Main';
import "bootstrap/dist/css/bootstrap.min.css";

const MobileView = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Get phone number from URL or localStorage
    const queryParams = new URLSearchParams(location.search);
    const urlPhone = queryParams.get('phone');
    const storedFullPhone = localStorage.getItem('phoneNumber');

    if (urlPhone) {
      const cleanPhone = urlPhone.replace(/\D/g, '');
      if (cleanPhone.length === 10) {
        setPhoneNumber(cleanPhone);
        localStorage.setItem('phoneNumber', `+91${cleanPhone}`);
      } else {
        navigate('/login');
      }
    } else if (storedFullPhone) {
      const phoneDigits = storedFullPhone.replace(/\D/g, '').slice(-10);
      if (phoneDigits.length === 10) {
        setPhoneNumber(phoneDigits);
      } else {
        navigate('/login');
      }
    } else {
      navigate('/login');
    }

    // Mobile back button handling
    const handlePopState = () => {
      if (/Mobi|Android/i.test(navigator.userAgent)) {
        window.history.pushState(null, '', window.location.href);
      }
    };

    window.history.pushState(null, '', window.location.href);
    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [navigate, location]);

  if (!phoneNumber) return null;

  return (
    <div className="d-flex justify-content-center align-items-center vh-100" 
         style={{ minHeight: "100vh", background: '#E5E5E5' }}>
      <div style={{ 
        maxWidth: '470px', 
        width: "100%", 
        background: 'white', 
        display: "flex", 
        flexDirection: "column", 
        overflow: "hidden",
        height: "100vh"
      }}>
        <Main phoneNumber={phoneNumber} />
      </div>
    </div>
  );
};

export default MobileView;







// import React, { useState, useEffect } from 'react';
// import { useNavigate, useLocation } from 'react-router-dom';
// import Main from './Main'; // Replace with your actual Main component

// const MobileView = () => {
//   const [phoneNumber, setPhoneNumber] = useState('');
//   const navigate = useNavigate();
//   const location = useLocation();

//   useEffect(() => {
//     const queryParams = new URLSearchParams(location.search);
//     const urlPhone = queryParams.get('phone');
//     const storedPhone = localStorage.getItem('phoneNumber');

//     if (urlPhone) {
//       const cleanPhone = urlPhone.replace(/\D/g, '');
//       if (cleanPhone.length === 10) {
//         setPhoneNumber(cleanPhone);
//         localStorage.setItem('phoneNumber', `+91${cleanPhone}`);
//       } else {
//         navigate('/');
//       }
//     } else if (storedPhone) {
//       const digits = storedPhone.replace(/\D/g, '').slice(-10);
//       if (digits.length === 10) {
//         setPhoneNumber(digits);
//       } else {
//         navigate('/');
//       }
//     } else {
//       navigate('/');
//     }
//   }, [navigate, location]);

//   if (!phoneNumber) return <div className="text-center mt-5">Loading...</div>;

//   return (
//     <div className="d-flex justify-content-center align-items-center vh-100" 
//          style={{ background: '#E5E5E5' }}>
//       <div style={{ 
//         maxWidth: '470px', 
//         width: '100%', 
//         background: 'white', 
//         height: '100vh',
//         overflow: 'hidden'
//       }}>
//         <Main phoneNumber={phoneNumber} />
//       </div>
//     </div>
//   );
// };

// export default MobileView;
// x