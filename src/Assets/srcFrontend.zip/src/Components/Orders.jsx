import React from 'react'
import PropertyCard from './PropertyCard'

export default function Orders() {
  return (
    <div>
<PropertyCard />
    </div>
  )
}
